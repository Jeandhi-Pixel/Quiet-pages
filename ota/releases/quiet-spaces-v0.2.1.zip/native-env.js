'use strict'; globalThis.QuietSpacesNative = true; globalThis.QuietSpacesNativeRevision = 1; document.documentElement.classList.add('quiet-native');
